Attribute VB_Name = "CI_Macro"
'
' https://github.com/VBA-Outils/Gerer-Tables-Parametrage
'
' Fonctions g�n�riques VBA
'
' @license MIT (http://www.opensource.org/licenses/mit-license.php)
'' ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ '
'
' Copyright (c) 2026, Vincent ROSSET
' All rights reserved.
'
' Redistribution and use in source and binary forms, with or without
' modification, are permitted provided that the following conditions are met:
'     * Redistributions of source code must retain the above copyright
'       notice, this list of conditions and the following disclaimer.
'     * Redistributions in binary form must reproduce the above copyright
'       notice, this list of conditions and the following disclaimer in the
'       documentation and/or other materials provided with the distribution.
'     * Neither the name of the <organization> nor the
'       names of its contributors may be used to endorse or promote products
'       derived from this software without specific prior written permission.
'
' THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
' ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
' WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
' DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
' DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
' (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
' LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
' ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
' (INCLUDING NEGligneCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
' SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
' ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ '

'-------------------------------------------------------------------------------------------------------------------------
' Macro : macros communes � la gestion des fichiers CSV et des tables SQL
'-------------------------------------------------------------------------------------------------------------------------

' +--------------------------------+-------------------------------------------------------------------------------------+
' | Fonction / Proc�dure           | Description                                                                         |
' +--------------------------------+-------------------------------------------------------------------------------------+
' | AjouterLigneContratInterface   | Ajouter une ou plusieurs nouvelles lignes dans le contrat d'interface               |
' | SupprimerLigneContratInterface | Supprimer une ou plusieurs lignes dans le contrat d'interface                       |
' | ReactualiserTables             | Cr�er les nouvelles tables dans de nouvelles feuilles                               |
' | ReactualiseListeTables         | Dans le contrat d'interface, r�actualise la liste des tables disponibles lors de    |
' |                                | l'ajout / suppression de lignes (point d'entr�e pour les boutons)                   |
' | CreerActualiserTables          | Dans le contrat d'interface, r�actualise la liste des tables disponibles lors de    |
' |                                | l'ajout / suppression de lignes (sous module)                                       |
' | CreerBouton                    | Cr�er les boutons en haut de la feuille qui contient une table                      |
' | ValeursListeFormat             | Retourne la liste des formats pour la liste d�roulante d'un type de donn�es         |
' +----------------------------------------------------------------------------------------------------------------------+

Option Explicit
Option Compare Text

' D�sactiver la gestion �v�nementielle de la feuille "Contrat Interface" avec un bool�ne (EnableEvents ne fonctionne pas correctement, lors de la suppression de lignes dans le tableau structur�, toutes les cellules supprim�es d�clenchent une modification de feuille)
Global DesactiverEvenement As Boolean

'-------------------------------------------------------------------------------------------------------------------------
' Proc�dure : AjouterLigneContratInterface
' R�le      : Ins�rer une nouvelle ligne dans le contrat d'interface
' R�sultat  : Une ligne est ajout�e apr�s la cellule s�lectionn�e
'-------------------------------------------------------------------------------------------------------------------------
Public Sub AjouterLigneContratInterface()

    ' Tableau structur� avec le contrat d'interface
    Dim tsContratInterface As xlTable
    ' Ligne apr�s laquelle ajouter une nouvelle ligne
    Dim lLigne As Long, aListeLignes() As Variant, IcLig As Long, lLignePrec As Long, lLigneRef As Long, xlRow As xlRow, lligneteteTS As Long
    ' Protection de la feuille
    Dim ProtectionCI As New ProtectionState
    
    ' Gestion des erreurs
    On Error GoTo Dysfonctionnement
    Call InitialiserTraitement
    DesactiverEvenement = True
    
    ' D�prot�ger la feuille afin de pouvoir ins�rer une ligne
    ProtectionCI.LoadFromWorksheet Worksheets(CI_NOM_FEUILLE_CONTRAT_INTERFACE)
    ProtectionCI.UnprotectWorksheet Worksheets(CI_NOM_FEUILLE_CONTRAT_INTERFACE), MOT_DE_PASSE_FEUILLE_PROTEGEE
    
    ' R�cup�re la liste des lignes s�lectionn�es
    aListeLignes() = ListeLignesSelectionnees(1)
    ' Cr�er un objet Tableau structur� qui va pointer sur le contrat d'interface
    Set tsContratInterface = New xlTable
    tsContratInterface.Init CI_LIB_TS_CONTRAT_INTERFACE, CI_TAB_STRUCT_NOM_TABLE
    
    ' Traiter toutes les lignes s�lectionn�es du num�ro le plus grand vers le plus petit (si on ins�re une ligne apr�s la plus petite alors on d�cale les num�ros suivants, et la lite  devient inexacte)
    lligneteteTS = tsContratInterface.ListObject.HeaderRowRange.Row
    For IcLig = UBound(aListeLignes) To LBound(aListeLignes) Step -1
        lLigne = aListeLignes(IcLig) - lligneteteTS + 1
        ' Si plusieurs lignes contigues sont s�lectionn�es alors on ins�re apr�s la derni�re ligne du groupe
        If lLigne = lLignePrec - 1 Then
            lLignePrec = lLigne
            ' Ajouter une ligne dans le tableau structur�
            Set xlRow = tsContratInterface.AddRow(lLigneRef)
        Else
            ' Ajouter une ligne dans le tableau structur�
            Set xlRow = tsContratInterface.AddRow(lLigne)
            lLigneRef = lLigne
            lLignePrec = lLigne
        End If
        ' Mise en forme de toutes les cellules de la ligne ajout�e
        Call MiseEnFormeCelluleCI(xlRow.ColumnByName(CI_TAB_STRUCT_NOM_TABLE), xlLeft, xlCenter, "", "General")
        Call MiseEnFormeCelluleCI(xlRow.ColumnByName(CI_TAB_STRUCT_ATTRIBUT), xlLeft, xlCenter, "", "General")
        Call MiseEnFormeCelluleCI(xlRow.ColumnByName(CI_TAB_STRUCT_TYPE_DONNEES), xlLeft, xlCenter, "=TypeDonnees", "@")
        Call MiseEnFormeCelluleCI(xlRow.ColumnByName(CI_TAB_STRUCT_LONGUEUR), xlRight, xlCenter, "", "0")
        Call MiseEnFormeCelluleCI(xlRow.ColumnByName(CI_TAB_STRUCT_CLE_PRIMAIRE), xlCenter, xlCenter, "=Choix", "General")
        Call MiseEnFormeCelluleCI(xlRow.ColumnByName(CI_TAB_STRUCT_NULL), xlCenter, xlCenter, "=Choix", "General")
        Call MiseEnFormeCelluleCI(xlRow.ColumnByName(CI_TAB_STRUCT_FORMAT), xlLeft, xlCenter, "", "General")
        Call MiseEnFormeCelluleCI(xlRow.ColumnByName(CI_TAB_STRUCT_TABLE_REFERENCEE), xlLeft, xlCenter, "=ListeTables", "General")
        Call MiseEnFormeCelluleCI(xlRow.ColumnByName(CI_TAB_STRUCT_CLE_ETRANGERE), xlLeft, xlCenter, "", "General")
    Next IcLig
    
    ' Prot�ger de nouveau la feuille
    ProtectionCI.ApplyToWorksheet Worksheets(CI_NOM_FEUILLE_CONTRAT_INTERFACE), MOT_DE_PASSE_FEUILLE_PROTEGEE
    
    Call TerminerTraitement
    Set tsContratInterface = Nothing
    Set ProtectionCI = Nothing
    DesactiverEvenement = False
    
    Exit Sub
    
Dysfonctionnement:
    
    ' Prot�ger la feuille
    ProtectionCI.ApplyToWorksheet Worksheets(CI_NOM_FEUILLE_CONTRAT_INTERFACE), MOT_DE_PASSE_FEUILLE_PROTEGEE
    Call TerminerTraitement
    
    MsgBox "Un grain de sable s'est gliss� dans la m�canique bien huil�e d'ajout de nouvelles lignes." & vbCrLf & _
           "Num�ro d'erreur : " & Err.Number & vbCrLf & "Description : " & Err.Description, vbCritical, "Ajouter une nouvelle ligne"

    Set ProtectionCI = Nothing
    Set tsContratInterface = Nothing
    DesactiverEvenement = False
    
End Sub

'-------------------------------------------------------------------------------------------------------------------------
' Proc�dure : MiseEnFormeCelluleCI
' R�le      : Mettre en forme une cellule du contrat d'interface
' R�sultat  : La cellule est formatt�e par d�faut
'-------------------------------------------------------------------------------------------------------------------------
Private Sub MiseEnFormeCelluleCI(Cellule As Range, AlignementHorizontal As Long, AlignementVertical As Long, ListeDeroulante As String, FormatLocal As String)
    
    With Cellule
        ' Format de la cellule
        .NumberFormat = FormatLocal
        ' Verrouillage de la cellule
        .Locked = False
        ' formule masqu�e avec une feuille de calcul prot�g�e
        .FormulaHidden = False
        ' Alignement du texte
        .HorizontalAlignment = AlignementHorizontal
        .VerticalAlignment = AlignementVertical
        .WrapText = False
        .Orientation = 0
        .AddIndent = False
        .IndentLevel = 0
        .ShrinkToFit = False
        .ReadingOrder = xlContext
        .MergeCells = False
        ' Police de caract�res
        With .Font
            .Name = "Calibri"
            .FontStyle = "Normal"
            .Size = 11
            .Strikethrough = False
            .Superscript = False
            .Subscript = False
            .OutlineFont = False
            .Shadow = False
            .Underline = xlUnderlineStyleNone
            .ThemeColor = xlThemeColorLight1
            .TintAndShade = 0
            .ThemeFont = xlThemeFontMinor
        End With
        ' Liste d�roulante si demand�
        If ListeDeroulante <> "" Then
            With .Validation
                .Delete
                .Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Operator:=xlBetween, Formula1:=ListeDeroulante
                .IgnoreBlank = True
                .InCellDropdown = True
                .InputTitle = ""
                .ErrorTitle = ""
                .InputMessage = ""
                .ErrorMessage = ""
                .ShowInput = True
                .ShowError = True
            End With
        End If
    End With
    
End Sub

'-------------------------------------------------------------------------------------------------------------------------
' Proc�dure : SupprimerLigneContratInterface
' R�le      : Supprimer une ligne dans le contrat d'interface
' R�sultat  : La ligne s�lectionn�e est supprim�e
'-------------------------------------------------------------------------------------------------------------------------
Public Sub SupprimerLigneContratInterface()

    ' Tableau structur� avec le contrat d'interface
    Dim tsContratInterface As xlTable
    ' Ligne apr�s laquelle ajouter une nouvelle ligne
    Dim lLigne As Long, aListeLignes() As Variant, IcLig As Long, lligneteteTS As Long
    ' Protection de la feuille
    Dim ProtectionCI As New ProtectionState
    
    ' Gestion des erreurs
    On Error GoTo Dysfonctionnement
    Call InitialiserTraitement
    DesactiverEvenement = True
    
    ' D�prot�ger la feuille afin de pouvoir ins�rer une ligne
    ProtectionCI.LoadFromWorksheet Worksheets(CI_NOM_FEUILLE_CONTRAT_INTERFACE)
    ProtectionCI.UnprotectWorksheet Worksheets(CI_NOM_FEUILLE_CONTRAT_INTERFACE), MOT_DE_PASSE_FEUILLE_PROTEGEE
    
    ' R�cup�re la liste des lignes s�lectionn�es
    aListeLignes() = ListeLignesSelectionnees(1)
    ' Cr�er un objet "Contrat interface"
    Set tsContratInterface = New xlTable
    tsContratInterface.Init CI_LIB_TS_CONTRAT_INTERFACE, CI_TAB_STRUCT_NOM_TABLE, ActiveWorkbook
    
    ' Pour chaque ligne s�lectionn�e, la supprimer du tableau structur� (� partir de la fin du tableau vers le d�but afin de pas supprimer les mauvaises lignes)
    lligneteteTS = tsContratInterface.ListObject.HeaderRowRange.Row
    For IcLig = UBound(aListeLignes) To LBound(aListeLignes) Step -1
        lLigne = aListeLignes(IcLig) - lligneteteTS
        tsContratInterface.RowByPosition(lLigne).Delete
    Next IcLig
    
    ' Prot�ger de nouveau la feuille
    ProtectionCI.ApplyToWorksheet Worksheets(CI_NOM_FEUILLE_CONTRAT_INTERFACE), MOT_DE_PASSE_FEUILLE_PROTEGEE
    Call TerminerTraitement
    Set tsContratInterface = Nothing
    Set ProtectionCI = Nothing
    
    ' R�actualiser la liste des tables (utile lorsqu'une table a �t� supprim�e)
    Call ReactualiseListeTables(ActiveWorkbook)
    DesactiverEvenement = False
    
    Exit Sub
    
Dysfonctionnement:
    
    ' Prot�ger la feuille
    ProtectionCI.ApplyToWorksheet Worksheets(CI_NOM_FEUILLE_CONTRAT_INTERFACE), MOT_DE_PASSE_FEUILLE_PROTEGEE
    Call TerminerTraitement
    
    MsgBox "Un grain de sable s'est gliss� dans la m�canique bien huil�e de suppression de ligne." & vbCrLf & _
           "Num�ro d'erreur : " & Err.Number & vbCrLf & "Description : " & Err.Description, vbCritical, "Supprimer une ligne"

    Set ProtectionCI = Nothing
    Set tsContratInterface = Nothing
    DesactiverEvenement = False
    
End Sub

'-------------------------------------------------------------------------------------------------------------------------
' Proc�dure : ReactualiserTables
' R�le      : Cr�er un nouvel onglet pour chaque nouvelle table pr�sente dans le contrat d'interface, et mettre � jour les tables existantes.
'             Appel de la macro depuis un bouton dans la feuille "Contrat Interface"
' R�sultat  : Nouvelles tables du contrat d'interface sont cr��es dans des nouveaux onglets.
'-------------------------------------------------------------------------------------------------------------------------
Public Sub ReactualiserTables()
    
    ' Horodatage du traitement
    Dim DebutTrt As Date, FinTrt As Date
    
    DebutTrt = Now
    
    ' Afficher le formulaire de progression du traitement
    With Formulaire
        .Afficher
        ' D�sactiver les saisies du formulaire et renseigner les valeurs
        ' Fonctionnalit� ex�cut�e
        With .ComboBoxExec
            .Value = FORM_EXEC_CREER_TABLES
            .Enabled = False
        End With
        ' Nom du classeur de travail
        With .ComboFic1
            .Value = ActiveWorkbook.Name
            .Enabled = False
        End With
    End With
    
    ' Appel de la macro d'actualisation et cr�ation des tables
    Call CreerActualiserTables(ActiveWorkbook)
    
    Formulaire.ActualiserTauxProgres (100)
    Formulaire.AfficherTexte (Format(Now, "hh:mm:ss") & " Fin du traitement.")
    
    FinTrt = Now
    Formulaire.AfficherTexte (Format(Now, "hh:mm:ss") & " Dur�e du traitement : " & Format(FinTrt - DebutTrt, "hh:mm:ss"))
    Formulaire.AfficherTexteComplet
    
End Sub

'-------------------------------------------------------------------------------------------------------------------------
' Proc�dure : CreerActualiserTables
' R�le      : Cr�er un nouvel onglet pour chaque nouvelle table pr�sente dans le contrat d'interface, et mettre � jour lestables existantes
' Pram�tres : Classeur (workbook)
' R�sultat  : Nouvelles tables du contrat d'interface sont cr��es dans des nouveaux onglets.
'-------------------------------------------------------------------------------------------------------------------------
Public Sub CreerActualiserTables(Classeur As Workbook)

    ' Tableau structur� qui contient le contrat d'interface
    Dim tsContratInterface As xlTable, rColonne As Range, lcColonne As listColumn
    Dim xlRowTsCI As xlRow, IcLig As Long, IcDernLig As Long
    Dim bColonneExiste As Boolean, bAjoutColonne As Boolean
    ' Donn�es du contrat d'interface
    Dim sNomTable As String, sAttribut As String, sNomOnglet As String, sLongueur As String, sClePrimaire As String, sColNullable As String
    Dim sFormat As String, sType As String, lAlignementHoriz As Long, sFormatLocal As String, bEstNull As Boolean
    Dim lNumDernColTS As Long, sNomTablePrec As String, bNouvelleTable As Boolean, Colonne As listColumn
    ' Tableau structur� de la table
    Dim xlTable As New xlTable, xlRow As xlRow
    Dim wsFeuille As Worksheet
    Dim lNbColTabStruct As Long, lNbColSuppr As Long
    ' Protection de la feuille "Contrat Interface"
    Dim ProtectionCI As New ProtectionState
    ' Contrat d'interface
    Dim ContratInterface As New CSV_Contrat_Interface
    ' Suivi de l'avancement du traitement
    Dim iProgression As Integer, iProgressionPrec As Integer, bErreurTrouvee As Boolean
    
    ' Gestion des erreurs
    On Error GoTo Dysfonctionnement
    Call InitialiserTraitement
    
    ' D�prot�ger la feuille afin de pouvoir ins�rer une ligne
    ProtectionCI.LoadFromWorksheet Worksheets(CI_NOM_FEUILLE_CONTRAT_INTERFACE)
    ProtectionCI.UnprotectWorksheet Worksheets(CI_NOM_FEUILLE_CONTRAT_INTERFACE), MOT_DE_PASSE_FEUILLE_PROTEGEE
    
    ' Se positionner sur le tableau du contrat d'interface
    Set tsContratInterface = New xlTable
    tsContratInterface.Init CI_LIB_TS_CONTRAT_INTERFACE, CI_TAB_STRUCT_NOM_TABLE, Classeur
    
    ' Derni�re ligne du contrat d'interface
    IcDernLig = tsContratInterface.ListObject.ListRows.Count
    bErreurTrouvee = False
    ' Supprimer les lignes sans nom de table et v�rifier les saisies
    For IcLig = IcDernLig To 1 Step -1
        Set xlRowTsCI = tsContratInterface.RowByPosition(IcLig)
        ' R�cup�rer les informations de la table (nom, attributs)
        sNomTable = xlRowTsCI.ColumnByName(CI_TAB_STRUCT_NOM_TABLE).Value
        sAttribut = xlRowTsCI.ColumnByName(CI_TAB_STRUCT_ATTRIBUT).Value
        sType = xlRowTsCI.ColumnByName(CI_TAB_STRUCT_TYPE_DONNEES).Value
        sLongueur = xlRowTsCI.ColumnByName(CI_TAB_STRUCT_LONGUEUR).Value
        sClePrimaire = xlRowTsCI.ColumnByName(CI_TAB_STRUCT_CLE_PRIMAIRE).Value
        sColNullable = xlRowTsCI.ColumnByName(CI_TAB_STRUCT_NULL).Value
        sFormat = xlRowTsCI.ColumnByName(CI_TAB_STRUCT_FORMAT).Value
        If sNomTable = "" Then
            Formulaire.AfficherTexte (Format(Now, "hh:mm:ss") & " Suppression de la ligne " & IcLig & " du contrat d'interface (Nom de table non renseign�).")
            tsContratInterface.RowByPosition(IcLig).Delete
        Else
            If sAttribut = "" Then
                Formulaire.AfficherTexte (Format(Now, "hh:mm:ss") & " Un attribut n'est pas renseign� dans la table """ & sNomTable & """.")
                bErreurTrouvee = True
            End If
            ' Longueur de l'attribut obligatoire
            Select Case sType
                Case "char", "varchar", "decimal"
                    ' La longueur est obligatoire
                    Select Case True
                        Case sLongueur = ""
                            Formulaire.AfficherTexte (Format(Now, "hh:mm:ss") & " Longueur non renseign�e pour la colonne """ & sAttribut & """ de la table """ & sNomTable & """.")
                            bErreurTrouvee = True
                        Case IsNumeric(sLongueur) = False
                            Formulaire.AfficherTexte (Format(Now, "hh:mm:ss") & " Longueur non num�rique pour la colonne """ & sAttribut & """ de la table """ & sNomTable & """.")
                            bErreurTrouvee = True
                    End Select
            End Select
            ' Le type de donn�es est obligatoire
            If sType = "" Then
                Formulaire.AfficherTexte (Format(Now, "hh:mm:ss") & " Le type de donn�es est obligatoire pour l'attribut """ & sAttribut & """ de la table """ & sNomTable & """.")
                bErreurTrouvee = True
            End If
            ' La colonne "cl� primaire" doit contenir les valeurs oui ou non
            If StrComp(sClePrimaire, "oui", vbTextCompare) <> 0 And StrComp(sClePrimaire, "non", vbTextCompare) <> 0 Then
                Formulaire.AfficherTexte (Format(Now, "hh:mm:ss") & " La cl� primaire doit �tre d�finie pour l'attribut """ & sAttribut & """ de la table """ & sNomTable & """.")
                bErreurTrouvee = True
            End If
            ' La colonne "Nullable" doit contenir les valeurs oui ou non
            If StrComp(sColNullable, "oui", vbTextCompare) <> 0 And StrComp(sColNullable, "non", vbTextCompare) <> 0 Then
                Formulaire.AfficherTexte (Format(Now, "hh:mm:ss") & " La valeur Null doit �tre d�finie pour l'attribut """ & sAttribut & """ de la table """ & sNomTable & """.")
                bErreurTrouvee = True
            End If
        End If
    Next IcLig
    
    ' Si aucune erreur n'a �t� trouv�e alors on poursuit le traitement
    If bErreurTrouvee = False Then
    
        ' Derni�re ligne du contrat d'interface
        IcDernLig = tsContratInterface.ListObject.ListRows.Count
        ' Initialiser les variables de rupture
        sNomTablePrec = ""
        bNouvelleTable = False
        
        ' Parcourir toutes les tables et tous les attributs pr�sents dans le contrat d'interface
        For IcLig = 1 To IcDernLig
        
            ' R�actualiser le formulaire de progression du traitement
            iProgression = CInt(IcLig / IcDernLig * 100)
            If iProgression <> iProgressionPrec Then
                iProgressionPrec = iProgression
                Formulaire.ActualiserTauxProgres (iProgression)
            End If
        
            Set xlRowTsCI = tsContratInterface.RowByPosition(IcLig)
            
            ' R�cup�rer les informations de la table (nom, attributs)
            sNomTable = Trim$(xlRowTsCI.ColumnByName(CI_TAB_STRUCT_NOM_TABLE).Value)
            If sNomTable <> "" Then
                ' Limite d'Excel, les noms des feuilles ne doivent pas avoir plus de 31 caract�res
                sNomOnglet = Left$(sNomTable, 31)
                sAttribut = Trim$(xlRowTsCI.ColumnByName(CI_TAB_STRUCT_ATTRIBUT))
                sType = Trim$(xlRowTsCI.ColumnByName(CI_TAB_STRUCT_TYPE_DONNEES))
                sFormat = Trim$(xlRowTsCI.ColumnByName(CI_TAB_STRUCT_FORMAT))
                bEstNull = IIf(StrComp(Trim$(xlRowTsCI.ColumnByName(CI_TAB_STRUCT_NULL)), "oui", vbTextCompare) = 0, True, False)
                
                ' Rupture sur le nom de la table ? Si oui alors il s'agit d'une table pas encore tait�e
                If StrComp(sNomTable, sNomTablePrec, vbTextCompare) <> 0 Then
                    Formulaire.AfficherTexte (Format(Now, "hh:mm:ss") & " Traitement de la table " & sNomTable & ".")
                    ' Si une nouvelle table a �t� ajout�e alors on cr�e un tableau structur� avec le nom de la table
                    If bNouvelleTable = True Then
                        ' Cr�er le tableau structur�
                        Call CreerTS(wsFeuille, CI_NUMERO_LIGNE_NOM_COLONNE, lNumDernColTS, sNomTablePrec)
                    End If
                    sNomTablePrec = sNomTable
                    lNumDernColTS = 0
                    ' Existe-t-il un onglet avec le nom de la table ?
                    If EstFeuilleExistante(Classeur, sNomOnglet) = False Then
                        ' C'est une nouvelle table dans le classeur : ajout d'un nouvel onglet au classeur
                        bNouvelleTable = True
                        ' Cr�ation d'un nouvel onglet avant le premier
                        Set wsFeuille = Classeur.Worksheets.Add(Before:=Worksheets(1))
                        wsFeuille.Name = sNomOnglet
                        ' Remplir la ligne d'en-t�te de l'onglet
                        wsFeuille.Cells(CI_NUMERO_LIGNE_NOM_TABLE, CI_NUMERO_COLONNE_LIB_TABLE).Value = CI_LIBELLE_NOM_TABLE
                        wsFeuille.Cells(CI_NUMERO_LIGNE_NOM_TABLE, CI_NUMERO_COLONNE_NOM_TABLE).Value = sNomTable
                        
                        ' Ajout du bouton qui ouvre le formulaire
                        Call CreerBouton(wsFeuille, "AfficherFormulaire", "G�rer les tables", 50, 0, 100, 15)
                        
                        ' Ajout du bouton Importer un fichier CSV
                        Call CreerBouton(wsFeuille, "ImporterFichierCSV", "Importer CSV", 170, 0, 100, 15)
                        
                        ' Ajout du bouton Exporter vers un fichier CSV
                        Call CreerBouton(wsFeuille, "ExporterFichierCSV", "Exporter CSV", 290, 0, 100, 15)
                        
                        ' Ajout du bouton Exporter vers une requ�te SQL
                        Call CreerBouton(wsFeuille, "ExporterRequeteSql", "Exporter SQL", 410, 0, 100, 15)
                        bAjoutColonne = True
                    Else
                        ' Table d�j� existante dans le classeur, on pointe dessus afin d'ajouter de nouvelles colonnes si n�cessaire
                        bNouvelleTable = False
                        ' Pointer su le tableau structur� qui contient la table
                        xlTable.Init sNomTable, CI_TAB_STRUCT_NOM_TABLE, Classeur
                        ' R�cup�rer le nom de la feuille qui contient la table
                        Set wsFeuille = xlTable.ListObject.Range.Worksheet
                        ' Charger le contrat d'interface de la table afin de v�rifier l'existence des colonnes pr�sentes dans le tableau structur�
                        With ContratInterface
                            .Classeur = Classeur
                            .NomTableauStructureCI = CI_LIB_TS_CONTRAT_INTERFACE
                            .NomTable = sNomTable
                        End With
                        ' Pour chaque colonne du tableau structur�, on v�rifie que le nom de la colonne est pr�sent dans le contrat d'interface afin de supprimer la colonne si elle est absente
                        lNbColTabStruct = xlTable.ListObject.ListColumns.Count
                        lNbColSuppr = 0
                        For Each lcColonne In xlTable.ListObject.ListColumns
                            If ContratInterface.NomColonneExiste(lcColonne.Name) = False Then
                                Formulaire.AfficherTexte (Format(Now, "hh:mm:ss") & " -> Suppression de la colonne " & lcColonne.Name & ".")
                                lcColonne.Delete
                                lNbColSuppr = lNbColSuppr + 1
                            End If
                        Next lcColonne
                        ' Si toutes les colonnes ont �t� supprim�es alors le tableau structur� n'existe plus, il doit �tre cr�� de nouveau
                        If lNbColSuppr = lNbColTabStruct Then
                            bNouvelleTable = True
                            bAjoutColonne = True
                            lNumDernColTS = 0
                        End If
                    End If
                End If
                
                ' Incr�mente le num�ro de la colonne � cr�er
                lNumDernColTS = lNumDernColTS + 1
                
                ' Si c'est une table d�j� pr�sente alors on v�rifie si une colonne a �t� ajout�e
                If bNouvelleTable = False Then
                    ' Le nom de la colonne du contrat d'interface est d�j� pr�sent dans le tableau structur� ?
                    bColonneExiste = False
                    For Each lcColonne In xlTable.ListObject.ListColumns
                        If StrComp(lcColonne.Name, sAttribut, vbTextCompare) = 0 Then
                            bColonneExiste = True
                            Exit For
                        End If
                    Next lcColonne
                    ' Si le nom de la colonne n'a pas �t� trouv�e alors on ajoute une nouvelle colonne dans le tableau structur�
                    If bColonneExiste = False Then
                        xlTable.AddColumn sAttribut, lNumDernColTS
                        bAjoutColonne = True
                    Else
                        bAjoutColonne = False
                    End If
                End If
                
                ' Cr�ation des colonnes dans la table
                If bAjoutColonne = True Then
                    Formulaire.AfficherTexte (Format(Now, "hh:mm:ss") & " -> Ajout de la colonne " & sAttribut & ".")
                    Select Case sType
                        Case "char", "varchar", "text", "boolean"
                            lAlignementHoriz = xlLeft
                            sFormatLocal = "@"
                        Case "smallint", "integer", "bigint"
                            lAlignementHoriz = xlRight
                            sFormatLocal = "0"
                        Case "real", "double", "decimal", "numeric"
                            lAlignementHoriz = xlRight
                            sFormatLocal = "# ##0,00"
                        Case "date"
                            lAlignementHoriz = xlRight
                            sFormatLocal = "jj/mm/aaaa"
                        Case "time"
                            lAlignementHoriz = xlRight
                            sFormatLocal = "hh:mm:ss"
                        Case "timestamp"
                            lAlignementHoriz = xlRight
                            sFormatLocal = "jj/mm/aaaa hh:mm:ss,000"
                    End Select
                    With wsFeuille.Cells(CI_NUMERO_LIGNE_NOM_COLONNE, lNumDernColTS)
                        .Value = sAttribut
                        .HorizontalAlignment = xlCenter
                        .VerticalAlignment = xlCenter
                    End With
                    If bNouvelleTable = True Then
                        ' Aligner la future premi�re ligne du tableau structu�
                        With wsFeuille.Cells(CI_NUMERO_LIGNE_NOM_COLONNE + 1, lNumDernColTS)
                            .HorizontalAlignment = lAlignementHoriz
                            .VerticalAlignment = xlTop
                            .NumberFormatLocal = sFormatLocal
                        End With
                    Else
                        ' Aligner toute la colonne si la colonne est ajout�e dans une table d�j� cr��e
                        With xlTable.Column(sAttribut).listColumn.DataBodyRange
                            .HorizontalAlignment = lAlignementHoriz
                            .VerticalAlignment = xlTop
                            .NumberFormatLocal = sFormatLocal
                        End With
                    End If
                End If
            End If
        Next IcLig
        
        ' Si une nouvelle table a �t� ajout�e alors on cr�e un tableau structur� avec le nom de la table
        If bNouvelleTable = True Then
            ' Cr�er le tableau structur�
            Call CreerTS(wsFeuille, CI_NUMERO_LIGNE_NOM_COLONNE, lNumDernColTS, sNomTable)
            Range(sNomTable & "[#All]").Columns.AutoFit
        End If
    
        Call ReactualiseListeTables(ActiveWorkbook)
    
    End If
    
    ' Prot�ger de nouveau la feuille
    ProtectionCI.ApplyToWorksheet Worksheets(CI_NOM_FEUILLE_CONTRAT_INTERFACE), MOT_DE_PASSE_FEUILLE_PROTEGEE
    
    Call TerminerTraitement
    Set tsContratInterface = Nothing
    Set ProtectionCI = Nothing
    Set xlTable = Nothing
    Set ContratInterface = Nothing
    
    Exit Sub
    
Dysfonctionnement:
    
    ' Prot�ger la feuille
    ProtectionCI.ApplyToWorksheet Worksheets(CI_NOM_FEUILLE_CONTRAT_INTERFACE), MOT_DE_PASSE_FEUILLE_PROTEGEE
    Call TerminerTraitement
    
    MsgBox "Un grain de sable s'est gliss� dans la m�canique bien huil�e de cr�ation des nouvelles tables." & vbCrLf & _
           "Num�ro d'erreur : " & Err.Number & vbCrLf & "Description : " & Err.Description, vbCritical, "Cr�ation des nouvelles feuilles de saisie"
    
    Set tsContratInterface = Nothing
    Set ProtectionCI = Nothing
    Set xlTable = Nothing
    Set ContratInterface = Nothing

End Sub

'-------------------------------------------------------------------------------------------------------------------------
' Proc�dure : ReactualiseListeTables
' R�le      : R�actuaise la liste d�roulante des noms de table
' R�sultat  : Nouvelles tables du contrat d'interface sont cr��es dans des nouveaux onglets
'-------------------------------------------------------------------------------------------------------------------------
Public Sub ReactualiseListeTables(Classeur As Workbook)

    ' Tableau structur� qui contient le contrat d'interface
    Dim tsContratInterface As xlTable, xlRowTsCI As New xlRow, IcLig As Long, IcDernLig As Long
    ' Tableau structur� avec la liste des tables
    Dim ListeTables As New xlTable, sNomTable As String, xlRowTable As xlRow
    Dim dListeNomTable As New Dictionary, vNomTable As Variant
    ' Protection de la feuille "Domaines de valeur"
    Dim ProtectionDV As New ProtectionState
    
    ' D�prot�ger la feuille afin de pouvoir ins�rer une ligne
    ProtectionDV.LoadFromWorksheet Worksheets(CI_NOM_FEUILLE_CONTRAT_INTERFACE)
    ProtectionDV.UnprotectWorksheet Worksheets(CI_NOM_FEUILLE_CONTRAT_INTERFACE), MOT_DE_PASSE_FEUILLE_PROTEGEE
    
    ' Se positionner sur le tableau du contrat d'interface
    Set tsContratInterface = New xlTable
    tsContratInterface.Init CI_LIB_TS_CONTRAT_INTERFACE, CI_TAB_STRUCT_NOM_TABLE, Classeur
    
    ' Derni�re ligne du contrat d'interface
    IcDernLig = tsContratInterface.ListObject.ListRows.Count
    
    ' Parcourir toutes les tables et tous les attributs pr�sents dans le contrat d'interface
    For IcLig = 1 To IcDernLig
        Set xlRowTsCI = tsContratInterface.RowByPosition(IcLig)
        ' R�cup�rer les informations de la table (nom, attributs)
        sNomTable = xlRowTsCI.ColumnByName(CI_TAB_STRUCT_NOM_TABLE).Value
        dListeNomTable(sNomTable) = True
    Next IcLig
    
    ' Vider la liste des tables
    Set ListeTables = New xlTable
    ListeTables.Init CI_TAB_STRUCT_LISTE_TABLES, CI_TAB_STRUCT_COL_LISTE_TABLES, Classeur
    ListeTables.Delete
        
    For Each vNomTable In dListeNomTable.Keys
        If Trim$(vNomTable) <> "" Then
            Set xlRowTable = ListeTables.AddRow
            xlRowTable.ColumnByPosition(1).Value = vNomTable
        End If
    Next vNomTable

    ' V�rifier que toutes les tables renseign�es dans la colonne "Table r�f�renc�e" existent toujours apr�s r�actualisation
    For IcLig = 1 To IcDernLig
        Set xlRowTsCI = tsContratInterface.RowByPosition(IcLig)
        ' R�cup�rer les informations de la table r�f�renc�e
        sNomTable = xlRowTsCI.ColumnByName(CI_TAB_STRUCT_TABLE_REFERENCEE).Value
        Set xlRowTable = ListeTables.RowByIndex(sNomTable)
        ' Si la table r�f�renc�e n'existe plus alors on efface le contenu de la cellule
        If ListeTables.RowByIndexNotFound = True Then
            xlRowTsCI.ColumnByName(CI_TAB_STRUCT_TABLE_REFERENCEE).Cells.ClearContents
        End If
    Next IcLig
    
    ' Tri par ordre alphab�tique
    With ListeTables.ListObject.Sort
        .Header = xlYes
        .MatchCase = False
        .Orientation = xlTopToBottom
        .SortMethod = xlPinYin
        .Apply
    End With
    
    ' Prot�ger de nouveau la feuille
    ProtectionDV.ApplyToWorksheet Worksheets(CI_NOM_FEUILLE_CONTRAT_INTERFACE), MOT_DE_PASSE_FEUILLE_PROTEGEE
    
    ' Ajuster la largeur de la colonne
    ListeTables.AutoFit
    
    Set tsContratInterface = Nothing
    Set ListeTables = Nothing
    
End Sub

'-------------------------------------------------------------------------------------------------------------------------
' Proc�dure : CreerBouton
' R�le      : Ajouter un bouton dans la feuille active afin de pouvoir ex�cuter une macro donn�e
' Param�tre : wsFeuille -> Objet Feuille dans lequel sera ajout� le bouton
'             NomMacro  -> Nom de la macro � ex�cuter lors d'un clic sur le bouton
'             LibBtn    -> Libell� affich� sur le bouton
'             PosHoriz  -> Position horizontale du bouton dans la feuille
'             PosVertic -> Position verticale du bouton dans la feuille
'             Longueur  -> Longueur du bouton
'             Hauteur   -> Hauteur du bouton
' R�sultat  : Bouton cr��
'-------------------------------------------------------------------------------------------------------------------------
Private Sub CreerBouton(wsFeuille As Worksheet, NomMacro As String, LibBtn As String, PosHoriz As Double, PosVertic As Double, Longueur As Double, Hauteur As Double)

    ' Ajout du bouton
    With wsFeuille
        .Buttons.Add(PosHoriz, PosVertic, Longueur, Hauteur).Select
        With Selection
            .OnAction = NomMacro
            .Characters.Text = LibBtn
            With .Characters(Start:=1, Length:=12).Font
                .Name = "Calibri"
                .FontStyle = "Normal"
                .Size = 11
                .Strikethrough = False
                .Superscript = False
                .Subscript = False
                .OutlineFont = False
                .Shadow = False
                .Underline = xlUnderlineStyleNone
                .ColorIndex = 1
            End With
            .Placement = xlFreeFloating
            .PrintObject = False
        End With
    End With
    
End Sub

'-------------------------------------------------------------------------------------------------------------------------
' Fonction  : ValeursListeFormat
' R�le      : Retourne la liste des formats pour la liste d�roulante d'un type de donn�es
' Param�tre : wsFeuille [Worksheet] - Objet feuille qui contient la cellule � inspecter
'             Cellule [Range]       - Objet Cellule dont on veut d�terminer si une liste d�roulante est pr�sente
' R�sultat  : La fonction retourne True si la cellule contient une liste d�roulante
'-------------------------------------------------------------------------------------------------------------------------
Public Function ValeursListeFormat(sTypeFormat As String) As String

    Dim xlFormat As New xlTable, xlRow As xlRow
    
    ' Initialiser le tableau structur�
    xlFormat.Init DV_TAB_STRUCT_FORMAT_DONNEES, DV_TAB_STRUCT_COL_TYPE_FORMAT, ActiveWorkbook
    ' Rechercher la premi�re valeur de la liste d�roulante
    Set xlRow = xlFormat.FirstRowByIndex(sTypeFormat)
    While xlFormat.EndOfRowByIndex = False
        ' Concat�ner toutes les valeurs de la liste d�roulante
        ValeursListeFormat = ValeursListeFormat & IIf(ValeursListeFormat = "", "", ",") & xlRow.ColumnByName(DV_TAB_STRUCT_COL_FORMAT_DONNEES).Value
        ' Rechercher la valeur suivante
        Set xlRow = xlFormat.NextRowByIndex
    Wend
    ' Lib�rer les ressources
    Set xlFormat = Nothing
    
End Function
