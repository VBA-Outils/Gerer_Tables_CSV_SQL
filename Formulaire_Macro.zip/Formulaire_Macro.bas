Attribute VB_Name = "Formulaire_Macro"
'
' https://github.com/VBA-Outils/Gerer-Tables-Parametrage
'
' Fonctions g�n�riques VBA
'
' @license MIT (http://www.opensource.org/licenses/mit-license.php)
'' ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ '
'
' Copyright (c) 2026, Vincent ROSSET
' All rights reserved.
'
' Redistribution and use in source and binary forms, with or without
' modification, are permitted provided that the following conditions are met:
'     * Redistributions of source code must retain the above copyright
'       notice, this list of conditions and the following disclaimer.
'     * Redistributions in binary form must reproduce the above copyright
'       notice, this list of conditions and the following disclaimer in the
'       documentation and/or other materials provided with the distribution.
'     * Neither the name of the <organization> nor the
'       names of its contributors may be used to endorse or promote products
'       derived from this software without specific prior written permission.
'
' THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
' ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
' WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
' DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
' DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
' (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
' LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
' ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
' (INCLUDING NEGligneCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
' SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
' ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ '

'-------------------------------------------------------------------------------------------------------------------------
' Macro : macros communes � la gestion du formulaire
'-------------------------------------------------------------------------------------------------------------------------

' +--------------------------------+-------------------------------------------------------------------------------------+
' | Fonction / Proc�dure           | Description                                                                         |
' +--------------------------------+-------------------------------------------------------------------------------------+
' | AfficherFormulaire             | Afficher le formulaire de gestion des tables                                        |
' | FormCopierMDD                  | Lors de la MAJ du code VBA, le nouveau fichier Excel ne contient pas les donn�es du |
' |                                | projet. Cette macro copie le mod�le de donn�es de l'ancien classeur vers le nouveau.|
' +--------------------------------+-------------------------------------------------------------------------------------+

Option Explicit
Option Compare Text

'-------------------------------------------------------------------------------------------------------------------------
' Proc�dure : AfficherFormulaire
' R�le      : Afficher le formulaire avec les diff�rents choix possibles : importer / exporter / comparer
' R�sultat  : Le formulaire est visible par l'utilisateur
'-------------------------------------------------------------------------------------------------------------------------
Public Sub AfficherFormulaire()

    Formulaire.Afficher
    
End Sub

'-------------------------------------------------------------------------------------------------------------------------
' Proc�dure : FormCopierMDD
' R�le      : Importer un fichier CSV ou un r�pertoire qui contient des fichiers CSV
' Param�tre : ZoneComm -> zone de communication entre le formulaire et les modules afin de transmettre l'ensemble des saisies
' R�sultat  : Fichier charg� dans le tableau structur�
'-------------------------------------------------------------------------------------------------------------------------
Public Sub FormCopierMDD(ZoneComm As ZoneCommFormCSV)

    ' Contrat d'interface des 2 fichiers
    Dim xlCiFic1 As New xlTable, xlCiFic2 As New xlTable
    ' Liste des tables
    Dim xlListeTables As New xlTable, IcLig As Long, sNomTable As String
    Dim xlTable1 As New xlTable, xlTable2 As New xlTable
    Dim xlRow As xlRow, rCelluleFormat As Range, sListeFormat As String, vValeur As Variant
    ' Protection de la feuille
    Dim ProtectionCI As New ProtectionState, bProtectionOtee As Boolean
    
    ' Gestion des erreurs
    On Error GoTo Dysfonctionnement
    Call InitialiserTraitement
    
    ' Activer le classeur cible
    Workbooks(ZoneComm.NomClasseur2).Activate
    
    Formulaire.AfficherTexte (Format(Now, "hh:mm:ss") & " Recopie du contrat d'interface de " & ZoneComm.NomClasseur1 & " dans " & ZoneComm.NomClasseur2 & ".")
    ' D�prot�ger la feuille afin de cr�er des listes d�roulantes
    ProtectionCI.LoadFromWorksheet Worksheets(CI_NOM_FEUILLE_CONTRAT_INTERFACE)
    ProtectionCI.UnprotectWorksheet Worksheets(CI_NOM_FEUILLE_CONTRAT_INTERFACE), MOT_DE_PASSE_FEUILLE_PROTEGEE
    bProtectionOtee = True
    
    ' Recopier le contrat d'interface
    xlCiFic1.Init CI_LIB_TS_CONTRAT_INTERFACE, CI_TAB_STRUCT_NOM_TABLE, Workbooks(ZoneComm.NomClasseur1)
    xlCiFic2.Init CI_LIB_TS_CONTRAT_INTERFACE, CI_TAB_STRUCT_NOM_TABLE, Workbooks(ZoneComm.NomClasseur2)
    ' Effacer le contrat d'interface du 2�me classeur
    With xlCiFic2
        .Delete
        ' Ajout d'une ligne afin de ne pas avoir un objet vide
        .AddRow
    End With
    ' Copie le contrat d'interface du premier fichier vers le second
    If Not xlCiFic1.ListObject.DataBodyRange Is Nothing Then
        xlCiFic1.CopyTo xlCiFic2
    End If
    ' Ajuste la largeur des colonnes du contrat d'interface du classeur 2
    xlCiFic2.AutoFit
    
    'Cr�er les listes d�roulantes des colonnes "Format" et "Table r�f�renc�e"
    For IcLig = 1 To xlCiFic2.ListObject.ListRows.Count
        Set xlRow = xlCiFic2.RowByPosition(IcLig)
        ' Cr�er les listes d�roulantes en fonction du type
        Select Case xlRow.ColumnByName(CI_TAB_STRUCT_TYPE_DONNEES).Value
            ' Types de format sans longueur et format personnalis�
            Case "boolean", "text"
                xlRow.ColumnByName(CI_TAB_STRUCT_LONGUEUR).ClearContents
                ' Aucune liste d�roulante pour les formats texte et bool�en
                Set rCelluleFormat = xlRow.ColumnByName(CI_TAB_STRUCT_FORMAT)
                rCelluleFormat.ClearContents
                If EstListeDeroulante(ActiveSheet, rCelluleFormat, MOT_DE_PASSE_FEUILLE_PROTEGEE) = True Then
                    rCelluleFormat.Validation.Delete
                End If
            ' Heure
            Case "time"
                xlRow.ColumnByName(CI_TAB_STRUCT_LONGUEUR).ClearContents
                ' Cr�er une liste d�roulante dans la colonne "Format" sp�cifique aux heures
                Set rCelluleFormat = xlRow.ColumnByName(CI_TAB_STRUCT_FORMAT)
                sListeFormat = ValeursListeFormat("Heure")
                Call AjouterListeDeroulante(rCelluleFormat, sListeFormat, True, True, True)
            ' Nombre entier : longueur non renseign�e
            Case "smallint", "integer", "bigint"
                xlRow.ColumnByName(CI_TAB_STRUCT_LONGUEUR).ClearContents
                ' Aucune liste d�roulante pour les formats entiers
                Set rCelluleFormat = xlRow.ColumnByName(CI_TAB_STRUCT_FORMAT)
                rCelluleFormat.ClearContents
                If EstListeDeroulante(ActiveSheet, rCelluleFormat, MOT_DE_PASSE_FEUILLE_PROTEGEE) = True Then
                    rCelluleFormat.Validation.Delete
                End If
            ' Nombre r�el : longueur non renseign�e, formats avec des d�cimales possibles
            Case "real", "double"
                xlRow.ColumnByName(CI_TAB_STRUCT_LONGUEUR).ClearContents
                ' Cr�er une liste d�roulante dans la colonne "Format" sp�cifique aux heures
                Set rCelluleFormat = xlRow.ColumnByName(CI_TAB_STRUCT_FORMAT)
                sListeFormat = ValeursListeFormat("Nombre")
                Call AjouterListeDeroulante(rCelluleFormat, sListeFormat, True, True, True)
            ' Date : v�rification des formats autoris�s
            Case "date"
                xlRow.ColumnByName(CI_TAB_STRUCT_LONGUEUR).ClearContents
                ' Cr�er une liste d�roulante dans la colonne "Format" sp�cifique aux heures
                Set rCelluleFormat = xlRow.ColumnByName(CI_TAB_STRUCT_FORMAT)
                sListeFormat = ValeursListeFormat("Date")
                Call AjouterListeDeroulante(rCelluleFormat, sListeFormat, True, True, True)
            ' Horodatage : v�rification des formats autoris�s
            Case "timestamp"
                xlRow.ColumnByName(CI_TAB_STRUCT_LONGUEUR).ClearContents
                ' Cr�er une liste d�roulante dans la colonne "Format" sp�cifique aux heures
                Set rCelluleFormat = xlRow.ColumnByName(CI_TAB_STRUCT_FORMAT)
                sListeFormat = ValeursListeFormat("Horodatage")
                Call AjouterListeDeroulante(rCelluleFormat, sListeFormat, True, True, True)
            ' Cha�ne de caract�res : format inutile
            Case "char", "varchar", "decimal"
                ' Aucune liste d�roulante pour les formats texte et d�cimal
                Set rCelluleFormat = xlRow.ColumnByName(CI_TAB_STRUCT_FORMAT)
                rCelluleFormat.ClearContents
                If EstListeDeroulante(ActiveSheet, rCelluleFormat, MOT_DE_PASSE_FEUILLE_PROTEGEE) = True Then
                    rCelluleFormat.Validation.Delete
                End If
        End Select
        
    Next IcLig
    ' Prot�ger de nouveau la feuille
    ProtectionCI.ApplyToWorksheet Worksheets(CI_NOM_FEUILLE_CONTRAT_INTERFACE), MOT_DE_PASSE_FEUILLE_PROTEGEE
    bProtectionOtee = False
    
    ' Si le contrat d'interface est vide
    If xlCiFic2.ListObject.DataBodyRange Is Nothing Then
        Formulaire.AfficherTexte (Format(Now, "hh:mm:ss") & " Contrat d'interface vide dans " & ZoneComm.NomClasseur2)
    Else
        Formulaire.AfficherTexte (Format(Now, "hh:mm:ss") & " Cr�er les tables dans " & ZoneComm.NomClasseur2)
        ' R�actualiser toutes les tables ou les cr�er si elles n'existent pas
        Call CreerActualiserTables(Workbooks(ZoneComm.NomClasseur2))
        
        ' Copie du contenu de toutes les tables du classeur 1 dans le classeur 2
        xlListeTables.Init CI_TAB_STRUCT_LISTE_TABLES, CI_TAB_STRUCT_COL_LISTE_TABLES, Workbooks(ZoneComm.NomClasseur2)
        For IcLig = 1 To xlListeTables.ListObject.ListRows.Count
            ' R�cup�re le nom de la table dans la liste des tables
            sNomTable = xlListeTables.RowByPosition(IcLig).Range.Value
            Formulaire.AfficherTexte (Format(Now, "hh:mm:ss") & " Copie du contenu de la table " & sNomTable & ". [" & IcLig & "/" & xlListeTables.ListObject.ListRows.Count & "]")
            ' Pointer sur le tableau structur� qui contient la table dans le classeur 2, puis supprimer le contenu de la table
            With xlTable2
                .Init sNomTable, "", Workbooks(ZoneComm.NomClasseur2)
                .Delete
                ' Ajout d'une ligne dans DataBodyRange afin de pouvoir copier les donn�es dedans
                .AddRow
            End With
            ' Copier les donn�es du tableau structur� du fichier 1 vers le tableau structur� du fichier 2
            With xlTable1
                .Init sNomTable, "", Workbooks(ZoneComm.NomClasseur1)
                .CopyTo xlTable2
            End With
            ' Ajuster la largeur des colonnes du tableau structur�
            xlTable2.AutoFit
        Next IcLig
    End If
    
    Call TerminerTraitement
    
    ' Lib�rer les ressources
    Set xlCiFic1 = Nothing
    Set xlCiFic2 = Nothing
    Set xlListeTables = Nothing
    Set xlTable1 = Nothing
    Set xlTable2 = Nothing
    Set ProtectionCI = Nothing
    
    Exit Sub
    
    ' Gestion des erreurs
Dysfonctionnement:

    ' Prot�ger de nouveau la feuille si besoin
    If bProtectionOtee = True Then
        ProtectionCI.ApplyToWorksheet Worksheets(CI_NOM_FEUILLE_CONTRAT_INTERFACE), MOT_DE_PASSE_FEUILLE_PROTEGEE
    End If
    Call TerminerTraitement
    
    Formulaire.AfficherTexte (Format(Now, "hh:mm:ss") & _
        " Un grain de sable s'est gliss� dans la m�canique bien huil�e de copie du MDD." & vbCrLf & _
        "Num�ro d'erreur : " & Err.Number & vbCrLf & "Description : " & Err.Description)
    
    Set xlCiFic1 = Nothing
    Set xlCiFic2 = Nothing
    Set xlListeTables = Nothing
    Set xlTable1 = Nothing
    Set xlTable2 = Nothing
    Set ProtectionCI = Nothing
    
End Sub
